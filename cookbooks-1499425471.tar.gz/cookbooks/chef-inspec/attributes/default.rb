default['java']['install_flavor'] = 'openjdk'  # this is the default, but let's be EXPLICIT!
default['java']['jdk_version'] = '7'
